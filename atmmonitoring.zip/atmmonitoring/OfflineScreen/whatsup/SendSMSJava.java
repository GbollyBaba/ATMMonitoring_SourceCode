// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3)
// Source File Name:   SendSMS.java

package com.zenithbank.postlion_events_notification;

import com.zenithbank.util.DBConnectionLive;
import com.zenithbank.util.HostDBException;
import java.io.PrintStream;
import java.sql.*;
import java.text.NumberFormat;

public class SendSMS
{

    public SendSMS()
    {
    }

    public static void main(String args[])
    {
        SendSMS sendsms = new SendSMS();
        try
        {
            sendsms.liveCon = new DBConnectionLive();
            sendsms.get_Support_Events();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            System.out.println("[main] " + exception.getMessage());
        }
    }

    private void get_Support_Events()
        throws HostDBException
    {
        String s = "jdbc:odbc:postilion_fepbackup";
        Object obj = null;
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            System.err.print("ClassNotFoundException: ");
            System.err.println(classnotfoundexception.getMessage());
        }
        try
        {
            Connection connection = DriverManager.getConnection(s, "", "");
            Statement statement = connection.createStatement();
            String s1 = "SELECT * FROM support_events_lookup";
            ResultSet resultset = statement.executeQuery(s1);
            resultset.next();
            int i = resultset.getInt("last_event_nr");
            NumberFormat numberformat = NumberFormat.getIntegerInstance();
            numberformat.setGroupingUsed(false);
            String s2 = numberformat.format(i);
            System.out.println("Retrieving support events to send by SMS...");
            s1 = "SELECT b.e_nr, a.gsm_no, b.event_nr, b.e_body, b.e_subject FROM support_members_sms AS a INNER JOIN support_email_log AS b ON a.email_address = b.e_to INNER JOIN support_notifications AS c ON b.event_nr = c.event_nr INNER JOIN support_sms_events AS d ON c.interface = d.interface AND c.event_id = d.event_id WHERE b.e_nr > " + s2 + " AND " + "DATEDIFF (dayofyear , b.e_datetime, getdate()) = 0 " + "ORDER BY b.event_nr ASC";
            for(ResultSet resultset1 = statement.executeQuery(s1); resultset1.next(); liveCon.UpdateQuery(s1))
            {
                i = resultset1.getInt("e_nr");
                String s3 = resultset1.getString("gsm_no");
                String s5 = resultset1.getString("e_body");
                String s6 = resultset1.getString("e_subject");
                int j = s6.indexOf(":") + 1;
                int k = s6.indexOf("(");
                String s7 = s6.substring(j, k);
                s5 = s7.trim() + ": " + s5.trim();
                System.out.println("Sending SMS to : " + s3);
                s1 = "INSERT INTO phoenix..sms_messages (recipient_addr, sender_addr, message, create_dt, status,ptid) VALUES ('" + s3 + "','08023038766','" + s5 + "', GETDATE(), 'Send'," + (new Integer(i)).toString() + ")";
            }

            if(i != Integer.parseInt(s2))
            {
                String s4 = numberformat.format(i);
                statement.executeUpdate("UPDATE support_events_lookup SET last_event_nr = " + s4);
            }
            statement.close();
            connection.close();
        }
        catch(HostDBException hostdbexception)
        {
            System.out.println("Send SMS event failed.");
            throw new HostDBException(203, "Send SMS event failed: " + hostdbexception.getMessage());
        }
        catch(SQLException sqlexception)
        {
            System.out.println("\n--- SQLException caught ---\n");
            sqlexception.printStackTrace();
            while(sqlexception != null)
            {
                System.out.println("Message:   " + sqlexception.getMessage());
                System.out.println("SQLState:  " + sqlexception.getSQLState());
                System.out.println("ErrorCode: " + sqlexception.getErrorCode());
                sqlexception = sqlexception.getNextException();
                System.out.println("");
            }
        }
    }

    private DBConnectionLive liveCon;
}