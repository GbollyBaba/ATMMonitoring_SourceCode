
SELECT b.e_nr, a.gsm_no, b.event_nr, b.e_body, b.e_subject 
FROM support_members_sms AS a ,support_email_log AS b, support_notifications AS c,support_sms_events AS d 

where 
a.email_address = b.e_to 

and b.event_nr = c.event_nr 

and c.interface = d.interface 
AND c.event_id = d.event_id 
----and b.e_nr > " + s2 + " 
---AND DATEDIFF (dayofyear , b.e_datetime, getdate()) = 0 
ORDER BY b.event_nr ASC
